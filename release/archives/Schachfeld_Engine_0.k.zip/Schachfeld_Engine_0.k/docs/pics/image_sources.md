Image-Sources
-------------

* schachfeld_winmine_12x12.png: own work, GPLv3
* flower-bouquet.jpg: 
[https://pixabay.com](https://web.archive.org/web/20161229043156/https://pixabay.com/en/service/terms/)
via [https://picryl.com](https://picryl.com/media/flower-bouquet-color-cut-flower-3a2f9b) 
under Creative Commons CC0 1.0 Universal Public Domain Dedication license 
